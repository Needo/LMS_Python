# Database Backup & Restore Setup Guide

## Prerequisites

### 1. PostgreSQL Tools Installation

The backup/restore feature requires PostgreSQL command-line tools (`pg_dump` and `pg_restore`).

#### Windows:
PostgreSQL tools are usually installed with PostgreSQL. Default path:
```
C:\Program Files\PostgreSQL\[VERSION]\bin
```

Update your `.env` file:
```
POSTGRES_BIN_PATH="C:\\Program Files\\PostgreSQL\\16\\bin"
```

#### Linux/Mac:
```bash
# Ubuntu/Debian
sudo apt-get install postgresql-client

# Mac
brew install postgresql
```

Update your `.env` file:
```
POSTGRES_BIN_PATH="/usr/bin"  # Linux
POSTGRES_BIN_PATH="/usr/local/bin"  # Mac (Homebrew)
```

### 2. Database Migration

Run the migration to create the required tables:

```bash
cd backend
python -m app.migrations.add_backup_tables
```

This creates:
- `backup_history` table - stores backup metadata
- `operation_lock` table - prevents concurrent operations

### 3. Backup Directory

The backups directory is created automatically at:
```
backend/backups/
```

Make sure the application has write permissions for this directory.

## Configuration

Add these settings to your `.env` file (optional, defaults shown):

```env
# Backup Configuration
BACKUP_DIR=./backups
MAX_BACKUP_SIZE=1073741824  # 1GB
MAX_BACKUPS_TO_KEEP=10
POSTGRES_BIN_PATH=/usr/bin  # Adjust for your system
```

## Usage

### Creating a Backup

1. Log in as an admin user
2. Navigate to Admin Panel
3. Scroll to "Database Backup & Restore" section
4. Click "Create Backup"
5. Wait for confirmation message

**What happens:**
- Database is backed up using `pg_dump`
- Backup is stored in `backend/backups/` directory
- Backup metadata is saved to database
- Old backups are auto-cleaned (keeps last 10)

### Downloading a Backup

1. Find the backup in the list
2. Click the download icon (⬇️)
3. Backup file will be downloaded to your computer

### Restoring from Backup

⚠️ **WARNING: This is a DESTRUCTIVE operation!**

1. Click the restore icon (↻) next to the backup
2. Read the warning dialog carefully
3. Check the confirmation checkbox
4. Click "Restore Database"
5. Wait for completion
6. You will be automatically logged out
7. Log back in

**What happens:**
- ALL current data is deleted
- Data from backup is restored
- All users are disconnected
- Application restarts

### Deleting a Backup

1. Click the delete icon (🗑️) next to the backup
2. Confirm deletion
3. Backup file and metadata are removed

## Operation Locking

Only ONE operation (backup, restore, or scan) can run at a time.

If you try to start an operation while another is running:
- You'll see an "Operation in progress" message
- Buttons will be disabled
- Status bar shows current operation type

## Troubleshooting

### "pg_dump command not found"

**Problem:** PostgreSQL tools are not in PATH

**Solution:**
1. Find your PostgreSQL installation directory
2. Update `POSTGRES_BIN_PATH` in `.env` file
3. Restart the backend server

### "Permission denied" when creating backup

**Problem:** No write permission for backup directory

**Solution:**
```bash
chmod 755 backend/backups
```

### Restore fails with errors

**Problem:** Backup file might be corrupted or from different PostgreSQL version

**Solution:**
1. Try a different backup file
2. Check PostgreSQL version compatibility
3. Re-scan filesystem to rebuild database

### Backup takes too long

**Problem:** Large database

**Solution:**
- This is normal for large databases
- Wait for completion (progress is shown)
- Consider cleanup of old data

## Best Practices

1. **Regular Backups**
   - Create backups before major changes
   - Schedule regular backups (manually for now)

2. **Test Restores**
   - Periodically test restoring from backup
   - Verify data integrity after restore

3. **Keep Multiple Backups**
   - Don't rely on a single backup
   - System keeps last 10 automatically

4. **Secure Backups**
   - Backup files contain sensitive data
   - Store downloads securely
   - Don't share backup files

5. **Before Restore**
   - Notify all users
   - Create a fresh backup first
   - Verify you have the correct backup file

## API Endpoints

All endpoints require admin authentication.

### POST /api/admin/backup/create
Create a new backup
```json
{
  "notes": "Optional notes about this backup"
}
```

### GET /api/admin/backup/list
List all backups

### GET /api/admin/backup/download/{backup_id}
Download a backup file

### POST /api/admin/backup/restore/{backup_id}
Restore from backup
```json
{
  "backup_id": 1,
  "confirm": true
}
```

### DELETE /api/admin/backup/{backup_id}
Delete a backup

### GET /api/admin/backup/status
Check current operation status

## Security Notes

- Only admin users can access backup features
- Operation locks prevent race conditions
- Backup files are stored locally (not in version control)
- All operations are logged with user information

## Recovery Procedure

If restore fails or database is corrupted:

1. **Option A: Restore from another backup**
   - Try a different backup file
   - Use the most recent successful backup

2. **Option B: Rebuild from filesystem**
   - Delete all data in database (if possible)
   - Run filesystem scan
   - Database will be rebuilt from files

3. **Option C: Manual database restore**
   ```bash
   # Using backup file directly
   pg_restore -h localhost -U postgres -d lms_db -c backups/backup_TIMESTAMP.sql
   ```

## Maintenance

### Cleaning Old Backups

Backups are auto-cleaned, keeping the last 10. To change:

Update `MAX_BACKUPS_TO_KEEP` in `.env`

### Manual Backup Cleanup

```bash
cd backend/backups
# List backups
ls -lh

# Delete old backups manually if needed
rm backup_20241201_*.sql
```

## Support

If you encounter issues:
1. Check backend logs for errors
2. Verify PostgreSQL tools are installed
3. Check file permissions
4. Ensure database connection is working

For additional help, refer to the main project documentation.
